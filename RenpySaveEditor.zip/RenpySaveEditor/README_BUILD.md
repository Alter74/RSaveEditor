# Compilar con GitHub Actions

1. Crea un repo en GitHub y sube **todo el contenido** de esta carpeta (incluye `gradlew`, `gradle/wrapper/gradle-wrapper.jar` y `.github/`).
2. Ve a **Actions → Build APK → Run workflow** (o simplemente haz push a `main`).
3. Al terminar, descarga el artefacto **apks** (`RSaveEditor-release.apk` y `RSaveEditor-debug.apk`).
4. Para publicar un Release automático: `git tag v1.0 && git push --tags`.

## Firma
- Por defecto el release se firma con la clave debug (instalable directamente).
- Para usar tu propia clave, crea estos *Secrets* en Settings → Secrets → Actions:
  `KEYSTORE_BASE64` (`base64 -w0 mi.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Local
`./gradlew assembleRelease` → `app/build/outputs/apk/release/`
