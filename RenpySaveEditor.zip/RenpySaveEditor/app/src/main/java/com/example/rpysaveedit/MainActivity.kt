package com.example.rpysaveedit

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {

    // ---------------------------------------------------------------- paleta
    private class Pal(val dark: Boolean, accent: Int) {
        val orange = accent
        val bar = accent
        val onBar = Color.parseColor("#1A1A1A")
        val bg = if (dark) Color.parseColor("#1B1B1D") else Color.parseColor("#F2F2F2")
        val surface = if (dark) Color.parseColor("#2A2A2D") else Color.WHITE
        val text = if (dark) Color.parseColor("#F1F1F1") else Color.parseColor("#1A1A1A")
        val muted = if (dark) Color.parseColor("#A6A6AB") else Color.parseColor("#6E6E6E")
        val btn = if (dark) Color.parseColor("#3A3A3E") else Color.parseColor("#D9D9D9")
        val pill = if (dark) Color.parseColor("#3A3A3E") else Color.parseColor("#E4E4E4")
        val stroke = if (dark) Color.parseColor("#48484D") else Color.parseColor("#D4D4D4")
        val primary = accent
        val onPrimary = Color.parseColor("#1A1A1A")
        val fab = accent
        val scrim = Color.parseColor("#2A2A2D")
    }

    private val accents = intArrayOf(
        Color.parseColor("#FB8500"), Color.parseColor("#4DA3FF"), Color.parseColor("#3DDC84"),
        Color.parseColor("#B388FF"), Color.parseColor("#FF6FA5"))
    private val steps = intArrayOf(1, 10, 100, 1000)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var titleView: TextView

    private val reqOpen = 1
    private val reqSaveAs = 2

    private lateinit var py: PyObject
    private lateinit var prefs: SharedPreferences
    private lateinit var pal: Pal

    private var uri: Uri? = null
    private var fileName = "save.save"
    private var loaded = false
    private var dirty = false
    private var fontScale = 1f
    private var filter = "all" // all | num | str | bool
    private var statusMsg = ""

    private val rows = ArrayList<JSONObject>()
    private lateinit var adapter: VarAdapter
    private lateinit var listView: ListView
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var emptyView: TextView
    private lateinit var downBtn: ImageView
    private val chips = ArrayList<Pair<String, TextView>>()

    // ------------------------------------------------------------ ciclo de vida
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        py = Python.getInstance().getModule("saveedit")
        prefs = getSharedPreferences("rsave", MODE_PRIVATE)
        buildUi()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (prefs.getString("theme", "light") == "system") rebuild()
    }

    // ------------------------------------------------------------ preferencias
    private fun isDark(): Boolean = when (prefs.getString("theme", "light")) {
        "dark" -> true
        "system" -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        else -> false
    }

    private fun scaleFor(i: Int): Float = when (i) { 1 -> 1.15f; 2 -> 1.3f; else -> 1f }

    private fun favs(): MutableSet<String> =
        HashSet(prefs.getStringSet("favs", emptySet()) ?: emptySet())

    // ------------------------------------------------------------ utilidades UI
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun TextView.sz(v: Float) = setTextSize(TypedValue.COMPLEX_UNIT_SP, v * fontScale)

    private fun round(color: Int, r: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun oval(color: Int): GradientDrawable =
        GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    private fun icon(res: Int, tint: Int, size: Int = 24): ImageView =
        ImageView(this).apply {
            setImageResource(res)
            setColorFilter(tint)
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun setStatus(m: String) {
        statusMsg = m
        status.text = m
        titleView.text = if (dirty) "RSave Editor  \u25CF" else "RSave Editor"
    }

    // ------------------------------------------------------------ construir la UI
    private fun rebuild() {
        val q = if (::search.isInitialized) search.text.toString() else ""
        buildUi()
        search.setText(q)
        refresh()
        if (statusMsg.isNotEmpty()) status.text = statusMsg
    }

    private fun buildUi() {
        pal = Pal(isDark(), accents[prefs.getInt("accent", 0).coerceIn(0, accents.size - 1)])
        fontScale = scaleFor(prefs.getInt("font", 0))
        window.statusBarColor = pal.bar
        chips.clear()

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this).apply { setBackgroundColor(pal.bg) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(col, FrameLayout.LayoutParams(match, match))

        // ---- barra superior
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(pal.bar)
            setPadding(dp(20), 0, dp(10), 0)
        }
        titleView = TextView(this).apply {
            text = "RSave Editor"
            setTextColor(pal.onBar)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            sz(24f)
        }
        bar.addView(titleView, lp(0, wrap, 1f))
        fun barBtn(res: Int, f: () -> Unit) = FrameLayout(this).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            addView(icon(res, pal.onBar, 26))
            setOnClickListener { f() }
        }
        bar.addView(barBtn(R.drawable.ic_undo) { undo() })
        bar.addView(barBtn(R.drawable.ic_history) { showHistory() })
        bar.addView(barBtn(R.drawable.ic_settings) { showSettings() })
        col.addView(bar, lp(match, dp(64)))

        // ---- botones Abrir / Guardar / Guardar como
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(14), dp(14), dp(4))
        }
        fun actBtn(t: String, res: Int?, primary: Boolean, f: () -> Unit): TextView =
            TextView(this).apply {
                text = t
                gravity = Gravity.CENTER
                maxLines = 2
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                sz(17f)
                setTextColor(if (primary) pal.onPrimary else pal.text)
                background = round(if (primary) pal.primary else pal.btn, 8)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                if (res != null) {
                    val d = resources.getDrawable(res, theme).mutate()
                    d.setTint(if (primary) pal.onPrimary else pal.text)
                    setCompoundDrawablesWithIntrinsicBounds(d, null, null, null)
                    compoundDrawablePadding = dp(6)
                }
                setOnClickListener { f() }
                layoutParams = lp(0, dp(66), 1f).apply { setMargins(dp(5), 0, dp(5), 0) }
            }
        actions.addView(actBtn("Abrir", null, false) { pickFile() })
        actions.addView(actBtn("Guardar", R.drawable.ic_save, true) { save() })
        actions.addView(actBtn("Guardar como", null, false) { saveAs() })
        col.addView(actions, lp(match, wrap))

        // ---- buscador
        val searchBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = round(pal.surface, 10)
            setPadding(dp(16), 0, dp(12), 0)
        }
        searchBox.addView(icon(R.drawable.ic_search, pal.muted, 26))
        search = EditText(this).apply {
            hint = "Buscar variable o valor…"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            sz(17f)
            setSingleLine()
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), dp(14), dp(8), dp(14))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        searchBox.addView(search, lp(0, wrap, 1f))
        col.addView(searchBox, lp(match, wrap).apply { setMargins(dp(14), dp(10), dp(14), dp(4)) })

        // ---- filtros (chips)
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        val defs = listOf("all" to "Todo", "fav" to "\u2605 Favoritos", "num" to "Números", "str" to "Textos", "bool" to "Sí/No")
        for ((key, label) in defs) {
            val chip = TextView(this).apply {
                text = label
                sz(16f)
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(10), dp(20), dp(10))
                setOnClickListener { filter = key; updateChips(); refresh() }
            }
            chips.add(key to chip)
            chipRow.addView(chip, lp(wrap, wrap).apply { setMargins(0, 0, dp(10), 0) })
        }
        updateChips()
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        }
        col.addView(chipScroll, lp(match, wrap))

        // ---- lista de tarjetas
        adapter = VarAdapter()
        listView = ListView(this).apply {
            divider = null
            dividerHeight = 0
            selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(14), dp(4), dp(14), dp(110))
            this.adapter = this@MainActivity.adapter
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(v: AbsListView?, s: Int) {}
                override fun onScroll(v: AbsListView?, first: Int, visible: Int, total: Int) {
                    downBtn.visibility =
                        if (total > 0 && first + visible < total) View.VISIBLE else View.GONE
                }
            })
        }
        val listFrame = FrameLayout(this)
        listFrame.addView(listView, FrameLayout.LayoutParams(match, match))
        col.addView(listFrame, lp(match, 0, 1f))

        status = TextView(this).apply {
            sz(13f)
            setTextColor(pal.muted)
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(dp(18), dp(4), dp(18), dp(8))
        }
        col.addView(status, lp(match, wrap))

        // ---- vista vacía
        emptyView = TextView(this).apply {
            gravity = Gravity.CENTER
            sz(18f)
            setTextColor(pal.muted)
            compoundDrawablePadding = dp(12)
            visibility = View.GONE
        }
        // el aviso vive dentro de la zona de la lista, así nunca tapa botones ni filtros
        listFrame.addView(emptyView, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))

        // ---- botón bajar al final
        downBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_arrow_down)
            setColorFilter(Color.WHITE)
            background = round(pal.scrim, 14)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            elevation = dp(6).toFloat()
            visibility = View.GONE
            setOnClickListener { listView.smoothScrollToPosition(adapter.count - 1) }
        }
        root.addView(downBtn, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(44) })

        // ---- FAB "Abrir"
        val fab = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = round(pal.fab, 12)
            elevation = dp(6).toFloat()
            setPadding(dp(22), dp(16), dp(24), dp(16))
            addView(icon(R.drawable.ic_folder, Color.parseColor("#1A1A1A"), 26))
            addView(TextView(this@MainActivity).apply {
                text = "Abrir"
                setTextColor(Color.parseColor("#1A1A1A"))
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                sz(19f)
                setPadding(dp(10), 0, 0, 0)
            })
            setOnClickListener { pickFile() }
        }
        root.addView(fab, FrameLayout.LayoutParams(wrap, wrap, Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(18), dp(40)) })

        setContentView(root)
        setStatus(if (loaded) statusMsg else "")
        updateEmpty()
    }

    private fun updateChips() {
        for ((key, chip) in chips) {
            val sel = key == filter
            chip.background = if (sel) round(pal.orange, 10) else round(pal.surface, 10)
            chip.setTextColor(if (sel) Color.parseColor("#1A1A1A") else pal.text)
            chip.typeface = if (sel) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.DEFAULT
        }
    }

    private fun updateEmpty() {
        val none = rows.isEmpty()
        emptyView.visibility = if (none) View.VISIBLE else View.GONE
        if (!none) return
        val d = resources.getDrawable(R.drawable.ic_folder, theme).mutate()
        d.setTint(pal.muted)
        emptyView.setCompoundDrawablesWithIntrinsicBounds(null, d, null, null)
        emptyView.text = if (loaded) "Sin resultados" else "Abre un archivo .save"
    }

    // ------------------------------------------------------------ tarjetas
    private inner class VarAdapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
            buildCard(position)
    }

    private fun buildCard(pos: Int): View {
        val o = rows[pos]
        val name = o.getString("name")
        val type = o.getString("type")
        val kind = o.getString("kind")
        val value = o.getString("value")
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val outer = FrameLayout(this).apply { setPadding(0, dp(6), 0, dp(6)) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = round(pal.surface, 10)
            setPadding(dp(18), dp(14), dp(8), dp(14))
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // nombre + tipo
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = name
            setTextColor(pal.text)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            sz(20f)
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
        }, lp(wrap, wrap, 0f))
        head.addView(TextView(this).apply {
            text = type
            setTextColor(pal.muted)
            sz(13f)
            background = round(pal.pill, 6)
            setPadding(dp(10), dp(3), dp(10), dp(3))
        }, lp(wrap, wrap).apply { setMargins(dp(10), 0, 0, 0) })
        left.addView(head, lp(wrap, wrap))

        // control según el tipo
        val ctrl = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        when (kind) {
            "num" -> {
                // al tocar el número se abre el teclado
                val valueTv = TextView(this).apply {
                    text = value
                    setTextColor(pal.text)
                    sz(28f)
                    gravity = Gravity.CENTER
                    minWidth = dp(76)
                    setPadding(dp(14), dp(4), dp(14), dp(4))
                    setOnClickListener { editValue(pos) }
                }
                // toque = un paso; mantener pulsado = repite
                fun stepBtn(t: String, dir: Int) = TextView(this).apply {
                    text = t
                    gravity = Gravity.CENTER
                    setTextColor(pal.text)
                    sz(26f)
                    background = round(pal.btn, 10)
                    layoutParams = lp(dp(46), dp(46))
                    var rep: Runnable? = null
                    setOnTouchListener { v, ev ->
                        when (ev.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                v.alpha = 0.6f
                                bump(pos, dir, valueTv)
                                val r = object : Runnable {
                                    override fun run() {
                                        bump(pos, dir, valueTv)
                                        handler.postDelayed(this, 70)
                                    }
                                }
                                rep = r
                                handler.postDelayed(r, 450)
                            }
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                v.alpha = 1f
                                rep?.let { handler.removeCallbacks(it) }
                                rep = null
                            }
                        }
                        true
                    }
                }
                ctrl.addView(stepBtn("\u2212", -1))
                ctrl.addView(valueTv, lp(wrap, wrap))
                ctrl.addView(stepBtn("+", 1))
            }
            "bool" -> {
                val label = TextView(this).apply {
                    text = value
                    setTextColor(pal.text)
                    sz(19f)
                    setPadding(dp(12), 0, 0, 0)
                }
                val sw = Switch(this).apply {
                    isChecked = value == "True"
                    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                    thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
                    trackTintList = ColorStateList(states, intArrayOf(pal.orange, pal.muted))
                    setOnCheckedChangeListener { _, checked ->
                        val err = py.callAttr("set_bool", name, checked).toString()
                        if (err.isEmpty()) {
                            label.text = if (checked) "True" else "False"
                            markDirty(name)
                            reloadRow(pos)
                        } else toast(err)
                    }
                }
                ctrl.addView(sw, lp(wrap, wrap))
                ctrl.addView(label, lp(wrap, wrap))
            }
            else -> {
                ctrl.addView(TextView(this).apply {
                    text = value
                    setTextColor(pal.text)
                    sz(if (kind == "str") 24f else 17f)
                    maxLines = 3
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dp(6), dp(8), dp(6))
                    setOnClickListener { editValue(pos) }
                }, lp(wrap, wrap))
            }
        }
        left.addView(ctrl, lp(wrap, wrap).apply { setMargins(0, dp(8), 0, 0) })
        card.addView(left, lp(0, wrap, 1f))

        // estrella de favoritos
        val isFav = favs().contains(name)
        val star = FrameLayout(this).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            addView(icon(if (isFav) R.drawable.ic_star else R.drawable.ic_star_outline,
                if (isFav) pal.orange else pal.muted, 34))
            setOnClickListener {
                val f = favs()
                if (!f.add(name)) f.remove(name)
                prefs.edit().putStringSet("favs", f).apply()
                refresh()
            }
        }
        card.addView(star, lp(wrap, wrap))

        outer.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap))
        return outer
    }

    // ------------------------------------------------------------ datos
    private fun refresh() {
        if (!loaded) { rows.clear(); adapter.notifyDataSetChanged(); updateEmpty(); return }
        val arr = JSONArray(
            py.callAttr("list_vars", search.text.toString(), if (filter == "fav") "all" else filter,
                !prefs.getBoolean("showpriv", false)).toString()
        )
        val fav = favs()
        val all = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) all.add(arr.getJSONObject(i))
        val base = if (filter == "fav") all.filter { fav.contains(it.getString("name")) } else all
        // favoritos primero (orden estable: mantiene el alfabético dentro de cada grupo)
        val sorted = if (prefs.getBoolean("favfirst", true))
            base.filter { fav.contains(it.getString("name")) } +
                base.filter { !fav.contains(it.getString("name")) }
        else base
        rows.clear(); rows.addAll(sorted)
        adapter.notifyDataSetChanged()
        updateEmpty()
        listView.post {
            val total = adapter.count
            downBtn.visibility = if (total > 0 &&
                listView.lastVisiblePosition < total - 1) View.VISIBLE else View.GONE
        }
    }

    private fun reloadRow(pos: Int) {
        if (pos < 0 || pos >= rows.size) return
        val name = rows[pos].getString("name")
        rows[pos] = JSONObject(py.callAttr("get_row", name).toString())
    }

    private fun markDirty(name: String) {
        dirty = true
        setStatus("«$name» modificado (sin guardar)")
    }

    private fun bump(pos: Int, dir: Int, valueTv: TextView) {
        if (pos >= rows.size) return
        val name = rows[pos].getString("name")
        val step = steps[prefs.getInt("step", 0).coerceIn(0, steps.size - 1)]
        val err = py.callAttr("adjust", name, dir, step).toString()
        if (err.isNotEmpty()) { toast(err); return }
        reloadRow(pos)
        valueTv.text = rows[pos].getString("value")
        markDirty(name)
    }

    private fun undo() {
        if (!loaded) return toast("Primero abre un save")
        val name = py.callAttr("undo").toString()
        if (name.isEmpty()) return toast("No hay nada que deshacer")
        refresh()
        setStatus("Deshecho: «$name»")
    }

    // ------------------------------------------------------------ edición con teclado
    private fun editValue(pos: Int) {
        val o = rows[pos]
        val name = o.getString("name")
        val type = o.getString("type")
        val raw = py.callAttr("get_raw", name).toString()

        val et = EditText(this).apply {
            setText(raw)
            selectAll()
            setTextColor(pal.text)
            sz(20f)
            background = round(pal.bg, 8, pal.stroke)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            inputType = when (type) {
                "int" -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
                "float" -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL
                "str" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }
            if (type == "int" || type == "float" || type == "str") {
                setSingleLine()
                imeOptions = EditorInfo.IME_ACTION_DONE
            } else {
                maxLines = 6
            }
        }
        et.setSelectAllOnFocus(true)

        val dlg = makeDialog()
        val box = dialogBox()
        box.addView(TextView(this).apply {
            text = name
            setTextColor(pal.text)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            sz(22f)
        })
        box.addView(TextView(this).apply {
            text = when (type) {
                "int" -> "Número entero"
                "float" -> "Número decimal"
                "str" -> "Texto"
                else -> "Valor Python (ej. [1, 2] o {'a': 1})"
            }
            setTextColor(pal.muted)
            sz(14f)
        }, lp(WC, WC).apply { setMargins(0, dp(2), 0, dp(14)) })
        box.addView(et, lp(ViewGroup.LayoutParams.MATCH_PARENT, WC))

        fun commit() {
            val err = py.callAttr("set_value", name, et.text.toString()).toString()
            if (err.isEmpty()) {
                dlg.dismiss()
                reloadRow(pos)
                adapter.notifyDataSetChanged()
                markDirty(name)
            } else toast(err)
        }

        val btns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        btns.addView(textBtn("Cancelar", pal.muted) { dlg.dismiss() })
        btns.addView(textBtn("Aceptar", pal.orange) { commit() })
        box.addView(btns, lp(ViewGroup.LayoutParams.MATCH_PARENT, WC).apply { setMargins(0, dp(16), 0, 0) })

        et.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_DONE) { commit(); true } else false
        }
        dlg.setContentView(box)
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dlg.show()
        et.requestFocus()
        et.postDelayed({
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
        }, 150)
    }

    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun makeDialog(): Dialog = Dialog(this).apply {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(round(pal.surface, 14))
        window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), WC)
    }

    private fun dialogBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(28), dp(26), dp(28), dp(18))
    }

    private fun textBtn(t: String, color: Int, f: () -> Unit): TextView = TextView(this).apply {
        text = t
        setTextColor(color)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        sz(18f)
        setPadding(dp(16), dp(10), dp(10), dp(10))
        setOnClickListener { f() }
    }

    // ------------------------------------------------------------ historial
    private fun showHistory() {
        if (!loaded) return toast("Primero abre un save")
        val arr = JSONArray(py.callAttr("changes").toString())
        val dlg = makeDialog()
        val box = dialogBox()
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        box.addView(TextView(this).apply {
            text = "Historial de cambios"
            setTextColor(pal.text)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            sz(24f)
        })
        box.addView(TextView(this).apply {
            text = if (arr.length() == 0) "Aún no has cambiado nada en este save."
            else "${arr.length()} variable(s) modificada(s) en esta sesión"
            setTextColor(pal.muted)
            sz(14f)
        }, lp(WC, WC).apply { setMargins(0, dp(2), 0, dp(12)) })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = round(pal.bg, 8)
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(TextView(this).apply {
                text = o.getString("name")
                setTextColor(pal.text)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                sz(17f)
            }, lp(0, WC, 1f))
            val n = o.getInt("n")
            head.addView(TextView(this).apply {
                text = (if (n > 1) "×$n · " else "") + o.getString("t")
                setTextColor(pal.muted)
                sz(12f)
            })
            row.addView(head)
            row.addView(TextView(this).apply {
                text = "${o.getString("old")}  \u2192  ${o.getString("new")}"
                setTextColor(pal.orange)
                sz(16f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }, lp(WC, WC).apply { setMargins(0, dp(3), 0, 0) })
            list.addView(row, lp(match, WC).apply { setMargins(0, 0, 0, dp(8)) })
        }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        box.addView(scroll, lp(match, WC))

        val btns = LinearLayout(this).apply { gravity = Gravity.END }
        if (arr.length() > 0) {
            btns.addView(textBtn("Deshacer todo", pal.muted) {
                val n = py.callAttr("undo_all").toInt()
                dlg.dismiss()
                refresh()
                setStatus("Se deshicieron $n cambio(s)")
            })
        }
        btns.addView(textBtn("Cerrar", pal.orange) { dlg.dismiss() })
        box.addView(btns, lp(match, WC).apply { setMargins(0, dp(8), 0, 0) })
        dlg.setContentView(box)
        dlg.show()
    }

    // ------------------------------------------------------------ ajustes
    private fun segmented(options: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(pal.surface, 8, pal.stroke)
        }
        options.forEachIndexed { i, t ->
            val tv = TextView(this).apply {
                text = t
                gravity = Gravity.CENTER
                sz(17f)
                setPadding(dp(6), dp(6), dp(6), dp(6))
                if (i == selected) {
                    background = round(pal.orange, 8)
                    setTextColor(Color.parseColor("#1A1A1A"))
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                } else setTextColor(pal.text)
                setOnClickListener { onPick(i) }
            }
            box.addView(tv, lp(0, dp(56), 1f))
        }
        return box
    }

    private fun showSettings() {
        val dlg = makeDialog()
        val box = dialogBox()
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        fun label(t: String) = TextView(this).apply {
            text = t
            setTextColor(pal.muted)
            sz(18f)
        }
        fun reopen() { dlg.dismiss(); rebuild(); showSettings() }

        box.addView(TextView(this).apply {
            text = "Configuración"
            setTextColor(pal.text)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            sz(28f)
        })

        val themes = listOf("light", "dark", "system")
        box.addView(label("Tema"), lp(WC, WC).apply { setMargins(0, dp(18), 0, dp(8)) })
        box.addView(segmented(listOf("Claro", "Oscuro", "Sistema"),
            themes.indexOf(prefs.getString("theme", "light")).coerceAtLeast(0)) { i ->
            prefs.edit().putString("theme", themes[i]).apply(); reopen()
        }, lp(match, WC))

        box.addView(label("Tamaño de letra"), lp(WC, WC).apply { setMargins(0, dp(18), 0, dp(8)) })
        box.addView(segmented(listOf("Normal", "Grande", "Muy grande"), prefs.getInt("font", 0)) { i ->
            prefs.edit().putInt("font", i).apply(); reopen()
        }, lp(match, WC))

        box.addView(label("Color de acento"), lp(WC, WC).apply { setMargins(0, dp(18), 0, dp(8)) })
        val accRow = LinearLayout(this)
        val curAcc = prefs.getInt("accent", 0)
        accents.forEachIndexed { i, c ->
            val dot = TextView(this).apply {
                gravity = Gravity.CENTER
                text = if (i == curAcc) "\u2713" else ""
                setTextColor(Color.parseColor("#1A1A1A"))
                sz(20f)
                background = round(c, 10).apply { if (i == curAcc) setStroke(dp(3), pal.text) }
                setOnClickListener { prefs.edit().putInt("accent", i).apply(); reopen() }
            }
            accRow.addView(dot, lp(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) })
        }
        box.addView(accRow, lp(match, WC))

        box.addView(label("Paso de + / \u2212 (mantén pulsado para repetir)"),
            lp(WC, WC).apply { setMargins(0, dp(18), 0, dp(8)) })
        box.addView(segmented(steps.map { it.toString() }, prefs.getInt("step", 0)) { i ->
            prefs.edit().putInt("step", i).apply(); reopen()
        }, lp(match, WC))

        fun switchRow(t: String, key: String, def: Boolean): View {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply {
                text = t
                setTextColor(pal.text)
                sz(19f)
            }, lp(0, WC, 1f))
            row.addView(Switch(this).apply {
                isChecked = prefs.getBoolean(key, def)
                val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
                trackTintList = ColorStateList(states, intArrayOf(pal.orange, pal.muted))
                setOnCheckedChangeListener { _, c ->
                    prefs.edit().putBoolean(key, c).apply()
                    if (key == "favfirst" || key == "showpriv") refresh()
                }
            })
            return row
        }
        box.addView(switchRow("Respaldo automático", "autobackup", true),
            lp(match, WC).apply { setMargins(0, dp(22), 0, 0) })
        box.addView(switchRow("Confirmar al sobrescribir", "confirm", false),
            lp(match, WC).apply { setMargins(0, dp(18), 0, 0) })
        box.addView(switchRow("Favoritos primero", "favfirst", true),
            lp(match, WC).apply { setMargins(0, dp(18), 0, 0) })
        box.addView(switchRow("Mostrar variables internas (_)", "showpriv", false),
            lp(match, WC).apply { setMargins(0, dp(18), 0, 0) })

        val close = LinearLayout(this).apply { gravity = Gravity.END }
        close.addView(textBtn("Cerrar", pal.orange) { dlg.dismiss() })
        box.addView(close, lp(match, WC).apply { setMargins(0, dp(14), 0, 0) })

        val scroll = android.widget.ScrollView(this).apply { addView(box) }
        dlg.setContentView(scroll)
        dlg.show()
    }

    // ------------------------------------------------------------ archivos
    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        startActivityForResult(i, reqOpen)
    }

    private fun queryName(u: Uri): String =
        contentResolver.query(u, null, null, null, null)?.use {
            val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && idx >= 0) it.getString(idx) else null
        } ?: "save.save"

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (resultCode != RESULT_OK || u == null) return
        try {
            when (requestCode) {
                reqOpen -> {
                    val bytes = contentResolver.openInputStream(u)!!.use { it.readBytes() }
                    val info = JSONObject(py.callAttr("load", bytes).toString())
                    uri = u
                    fileName = queryName(u)
                    loaded = true
                    dirty = false
                    var s = "$fileName — ${info.getInt("n")} variables"
                    val inner = info.getString("inner")
                    if (inner.isNotEmpty()) s += " (dentro: $inner)"
                    if (info.getInt("saves") > 1) s += " · +${info.getInt("saves") - 1} saves más en el zip"
                    setStatus(s)
                    refresh()
                }
                reqSaveAs -> {
                    val out = py.callAttr("export").toJava(ByteArray::class.java)
                    contentResolver.openOutputStream(u, "wt")!!.use { it.write(out) }
                    dirty = false
                    setStatus("Guardado como copia")
                    toast("Guardado como copia")
                }
            }
        } catch (e: Exception) {
            toast(cleanError(e))
        }
    }

    private fun cleanError(e: Exception): String {
        // Chaquopy envuelve los errores de Python como "ValueError: mensaje"
        val m = e.message ?: return "Error desconocido"
        return m.substringAfter("ValueError: ", m)
    }

    private fun save() {
        if (uri == null) return toast("Primero abre un save")
        if (prefs.getBoolean("confirm", false)) {
            val dlg = makeDialog()
            val box = dialogBox()
            box.addView(TextView(this).apply {
                text = "¿Sobrescribir el archivo?"
                setTextColor(pal.text)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                sz(22f)
            })
            box.addView(TextView(this).apply {
                text = fileName
                setTextColor(pal.muted)
                sz(16f)
            }, lp(WC, WC).apply { setMargins(0, dp(6), 0, dp(10)) })
            val btns = LinearLayout(this).apply { gravity = Gravity.END }
            btns.addView(textBtn("Cancelar", pal.muted) { dlg.dismiss() })
            btns.addView(textBtn("Sobrescribir", pal.orange) { dlg.dismiss(); doSave() })
            box.addView(btns)
            dlg.setContentView(box)
            dlg.show()
        } else doSave()
    }

    private fun doSave() {
        val u = uri ?: return
        try {
            var backupInfo = ""
            if (prefs.getBoolean("autobackup", true)) {
                val orig = py.callAttr("original").toJava(ByteArray::class.java)
                val dir = File(getExternalFilesDir(null), "backups").apply { mkdirs() }
                val bak = File(dir, "$fileName.bak")
                if (!bak.exists()) bak.writeBytes(orig)
                backupInfo = " Respaldo en ${bak.parent}"
            }
            val out = py.callAttr("export").toJava(ByteArray::class.java)
            contentResolver.openOutputStream(u, "wt")!!.use { it.write(out) }
            dirty = false
            setStatus("Guardado.$backupInfo")
            toast("Guardado")
        } catch (e: Exception) {
            toast("No se pudo sobrescribir (${cleanError(e)}). Usa «Guardar como».")
        }
    }

    private fun saveAs() {
        if (uri == null) return toast("Primero abre un save")
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
        startActivityForResult(i, reqSaveAs)
    }
}
